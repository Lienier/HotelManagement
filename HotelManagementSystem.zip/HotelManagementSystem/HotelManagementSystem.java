import java.util.List;
import java.util.Scanner;

public class HotelManagementSystem {

    private static final RoomDAO roomDAO = new RoomDAO();
    private static final GuestDAO guestDAO = new GuestDAO();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean exit = false;
        
        boolean authenticated = Login.authenticateLogin(scanner);
        
        if (!authenticated) {
            System.out.println("Invalid credentials. Exiting system.");
            return;
        } else {
            System.out.println("");
        }

        while (!exit) {
            System.out.println("\n\t\t\t\t\t\t\t\tHotel Management System");
            System.out.println("\t\t\t\t\t\t\t\t1. View All Rooms");
            System.out.println("\t\t\t\t\t\t\t\t2. Add Guest");
            System.out.println("\t\t\t\t\t\t\t\t3. Check-In a Guest");
            System.out.println("\t\t\t\t\t\t\t\t4. Check-Out a Guest");
            System.out.println("\t\t\t\t\t\t\t\t5. Exit");
            System.out.print("\t\t\t\t\t\t\t\tEnter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    Login.clearConsole();
                    System.out.println("\t\t\t\t\t\t\t\tRoom no.   Room Type    Available");
                    viewAllRooms(); // Show all rooms
                    
                    break;
                case 2:
                    Login.clearConsole();
                    addGuest(scanner); // Add a new guest still on test
                    break; 
                case 3:
                    Login.clearConsole();
                    System.out.println("\t\t\t\t\t\t\t\tRoom no.   Room Type    Available");
                     viewAllRooms();
                    checkInGuest(scanner); // Check-in a guest
                    break;
                case 4:
                    Login.clearConsole();
                    System.out.println("\t\t\t\t\t\t\t\tRoom no.   Room Type    Available");
                    viewAllRooms();
                    checkOutGuest(scanner); // Check-out a guest
                    break;
                case 5:
                    Login.clearConsole();
                    exit = true;
                    System.out.println("Exiting the system. Thank you!");
                    break;
                default:
                    Login.clearConsole();
                    System.out.println("Invalid choice. Please try again.");
            }
        }

        scanner.close();
    }

    private static void viewAllRooms() {
        List<Room> rooms = roomDAO.getAllRooms();
        rooms.forEach(System.out::println);
    }

    private static void addGuest(Scanner scanner) {
        System.out.print("Enter Guest ID: ");
        int guestId = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter Guest Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Contact Number: ");
        String contact = scanner.nextLine();
        System.out.print("Enter Email Address: ");
        String email = scanner.nextLine();

        Guest guest = new Guest(guestId, name, contact, email);
        guestDAO.addGuest(guest);
        System.out.println("Guest added successfully.");
    }
    private static void checkInGuest(Scanner scanner) {

    System.out.print("\n\n\n\t\t\t\tEnter Room Number for Check-In: ");
    int roomNumber = scanner.nextInt();
    scanner.nextLine();

    System.out.print("\t\t\t\tEnter Guest Name for Check-In: ");
    String guestName = scanner.nextLine();
    
    String confirm;
    boolean validInput = false;
    
    do {
        System.out.print("\t\t\t\tDo you confirm this booking (y/n)?: ");
        confirm = scanner.nextLine();

        if (confirm.equalsIgnoreCase("y")) {
            validInput = true;
            if (roomDAO.checkIn(roomNumber, guestName, new java.util.Date())) {
                 Login.clearConsole();
                System.out.println("\t\t\t\tGuest checked in successfully to room " + roomNumber);
                  System.out.println("\t\t\t\t\t\t\t\tRoom no.   Room Type    Available");
                    viewAllRooms();
            } else {
                System.out.println("\t\t\t\tCheck-in failed. Room may be unavailable or does not exist.");
            }
        } else if (confirm.equalsIgnoreCase("n")) {
            validInput = true; 
            System.out.println("\t\t\t\tBooking canceled.");
        }
        else {
            System.out.println("\t\t\t\tInvalid input. Please enter 'y' for yes or 'n' for no.");
        }
    } while (!validInput);
}


    private static void checkOutGuest(Scanner scanner) {
        boolean validinput = false;
        
        System.out.print("Enter Room Number for Check-Out: ");
        int roomNumber = scanner.nextInt();
        scanner.nextLine();
    do{
        System.out.print("Confirm the Check-out? (y/n)");
        String confirm = scanner.nextLine();
    if(confirm.equalsIgnoreCase("y")){
        validinput= true;
        
        if (roomDAO.checkOut(roomNumber, new java.util.Date())) {
             Login.clearConsole();
            System.out.println("Guest checked out successfully from room " + roomNumber);
             System.out.println("\t\t\t\t\t\t\t\tRoom no.   Room Type    Available");
                    viewAllRooms();
        } else {
            System.out.println("Check-out failed. Room may not be occupied or does not exist.");
        }
    }
    else if (confirm.equalsIgnoreCase("n")){
        validinput = true;
        System.out.println("Booking canceled.");
    }
     else {
            System.out.println("\t\t\t\tInvalid input. Please enter 'y' for yes or 'n' for no.");
        }
    
    }while(!validinput);
}
}
