public class Booking {
    private int bookingId;
    private String guestName;
    private int roomNumber;

    public Booking(int bookingId, String guestName, int roomNumber) {
        this.bookingId = bookingId;
        this.guestName = guestName;
        this.roomNumber = roomNumber;
    }

    // Getters
    public int getBookingId() {
        return bookingId;
    }

    public String getGuestName() {
        return guestName;
    }

    public int getRoomNumber() {
        return roomNumber;
    }

    @Override
    public String toString() {
        return "Booking ID: " + bookingId + ", Guest Name: " + guestName + ", Room Number: " + roomNumber;
    }
}
