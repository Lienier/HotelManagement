public class Room {
    private int roomNumber;
    private String type;
    private boolean isAvailable;

    // Constructor
    public Room(int roomNumber, String type, boolean isAvailable) {
        this.roomNumber = roomNumber;
        this.type = type;                    
        this.isAvailable = isAvailable;
    }

    // Getters
    public int getRoomNumber() {
        return roomNumber;
    }

    public String getType() {
        return type;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    // Setters
    public void setAvailable(boolean available) {
        this.isAvailable = available;
    }

    // Override toString()
    @Override
    public String toString() {
     
        return "\t\t\t\t\t\t\t      |   " + roomNumber + "   |   " + type + "  |     " + (isAvailable ? "Yes" : "No");
    }
}
