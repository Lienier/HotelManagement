import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Hotel {
    private static RoomDAO roomDAO = new RoomDAO();
    private static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    // Method to check in a guest
    public static void checkIn(int roomNumber, String guestName, String checkInDateStr) {
        try {
            Date checkInDate = dateFormat.parse(checkInDateStr);
            if (roomDAO.checkIn(roomNumber, guestName, checkInDate)) {
                System.out.println("Guest checked in successfully.");
            } else {
                System.out.println("Failed to check in the guest.");
            }
        } catch (ParseException e) {
            System.out.println("Invalid date format. Please use yyyy-MM-dd.");
        }
    }

    // Method to check out a guest
    public static void checkOut(int roomNumber, String checkOutDateStr) {
        try {
            Date checkOutDate = dateFormat.parse(checkOutDateStr);
            if (roomDAO.checkOut(roomNumber, checkOutDate)) {
                System.out.println("Guest checked out successfully.");
            } else {
                System.out.println("Failed to check out the guest.");
            }
        } catch (ParseException e) {
            System.out.println("Invalid date format. Please use yyyy-MM-dd.");
        }
    }

    // View all rooms
    public static void viewAllRooms() {
        roomDAO.getAllRooms().forEach(room -> System.out.println(room));
    }

    // Book a room
    public static boolean bookRoom(int roomNumber, String guestName) {
        return roomDAO.bookRoom(roomNumber, guestName);
    }
}
