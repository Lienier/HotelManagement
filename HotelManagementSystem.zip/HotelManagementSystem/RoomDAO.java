import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;
import java.sql.Date;

public class RoomDAO {
    
       public List<Room> getAllRooms() {// pag cout lang ng available rooms connected sa main class
        List<Room> rooms = new ArrayList<>();
        String query = "SELECT room_number, type, is_available FROM rooms";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                int roomNumber = rs.getInt("room_number");
                String type = rs.getString("type");
                boolean isAvailable = rs.getBoolean("is_available");

                Room room = new Room(roomNumber, type, isAvailable);
                rooms.add(room);
            }

            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return rooms;  // Return list ng room
    }

    // Get Room by its room number
    public Room getRoomByNumber(int roomNumber) {
        String query = "SELECT room_number, type, is_available FROM rooms WHERE room_number = ?";
        Room room = null;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, roomNumber);

            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                int number = rs.getInt("room_number");
                String type = rs.getString("type");
                boolean isAvailable = rs.getBoolean("is_available");

                // Gagawa ng Room object
                room = new Room(number, type, isAvailable);
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return room; // Return the Room object or null pag walang nakita
        
        
    }

    // Update yung availability ng room
    public void updateRoomAvailability(int roomNumber, boolean isAvailable) {
        String query = "UPDATE rooms SET is_available = ? WHERE room_number = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setBoolean(1, isAvailable);
            pstmt.setInt(2, roomNumber);

            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Book a room and change its availability status (already present)
    public boolean bookRoom(int roomNumber) {
        Room room = getRoomByNumber(roomNumber);
        if (room != null && room.isAvailable()) {
            updateRoomAvailability(roomNumber, false);
            return true;
        } else {
            System.out.println("Room is either unavailable or does not exist.");
            return false;
        }
    }
    
      public boolean isRoomAvailable(int roomNumber) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        boolean available = false;

        try {
            conn = DatabaseConnection.getConnection();
            String query = "SELECT is_available FROM rooms WHERE room_number = ?";
            pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, roomNumber);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                available = rs.getBoolean("is_available");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return available;  // Return true pag meron room , false pag wala
    }
    
      // Check-in guest
    public boolean checkIn(int roomNumber, String guestName, java.util.Date checkInDate) {
        Room room = getRoomByNumber(roomNumber);

        if (room != null && room.isAvailable()) {

            String insertBooking = "INSERT INTO bookings (room_number, guest_name, check_in_date) VALUES (?, ?, ?)";

            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(insertBooking)) {

                pstmt.setInt(1, roomNumber);
                pstmt.setString(2, guestName);
                pstmt.setDate(3, new Date(checkInDate.getTime())); //java.util.Date to java.sql.Date

                pstmt.executeUpdate();

                // Mark room as unavailable
                updateRoomAvailability(roomNumber, false);

                System.out.println("Check-in successful for " + guestName);
                return true;

            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("Room is either unavailable or does not exist.");
        }
        return false;
    }

    // Check-out a guest
    public boolean checkOut(int roomNumber, java.util.Date checkOutDate) {
        Room room = getRoomByNumber(roomNumber);

        if (room != null && !room.isAvailable()) {

            String updateBooking = "UPDATE bookings SET check_out_date = ? WHERE room_number = ? AND check_out_date IS NULL";

            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(updateBooking)) {

                pstmt.setDate(1, new Date(checkOutDate.getTime()));
                pstmt.setInt(2, roomNumber);

                int rowsUpdated = pstmt.executeUpdate();
                if (rowsUpdated > 0) {

                    updateRoomAvailability(roomNumber, true);

                    System.out.println("Check-out successful for room number: " + roomNumber);
                    return true;
                } else {
                    System.out.println("Check-out failed. No active booking found for the room.");
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("Room is already available or does not exist.");
        }
        return false;
    }
    public boolean bookRoom(int roomNumber, String guestName) {
    Room room = getRoomByNumber(roomNumber);
    if (room != null && room.isAvailable()) {
        // Proceed with the booking and update room availability
        return checkIn(roomNumber, guestName, new java.util.Date()); // Assume current date for check-in
    } else {
        System.out.println("Room is either unavailable or does not exist.");
        return false;
    }
}

    
}
