import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Login {
    static final String DB_URL = "jdbc:mysql://localhost:3306/hotel_db";
    static final String DB_USER = "root";
    static final String DB_PASS = "Ra200405";

    // method ng pag log in
    public static boolean authenticateLogin(Scanner scanner) {
        boolean isAuthenticated = false;

        while (!isAuthenticated) { 
            System.out.print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\t\t\t\t\t\t\t\tEnter username: ");
            String username = scanner.nextLine();
            System.out.print("\t\t\t\t\t\t\t\tEnter password: ");
            String password = scanner.nextLine();

            isAuthenticated = authenticate(username, password);
            
            if (!isAuthenticated) {
                System.out.println("\t\t\t\t\t\t\t\tIncorrect username or password. Please try again.");
                try
                {
                    Thread.sleep(2000);//para makita lang
                }
                catch (InterruptedException ie)
                {
                    ie.printStackTrace();
                }
                clearConsole();
            } else {
                System.out.println("\t\t\t\t\t\t\t\tLogin successful.");
                   try
                {
                    Thread.sleep(2000);
                }
                catch (InterruptedException ie)
                {
                    ie.printStackTrace();
                }
                clearConsole();
            }
        }

        return true;  
    }

    public static boolean authenticate(String username, String password) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);

            String query = "SELECT * FROM admin WHERE user = ? AND pass = ?";
            pstmt = conn.prepareStatement(query);
            pstmt.setString(1, username);
            pstmt.setString(2, password);

            rs = pstmt.executeQuery();
            return rs.next(); 

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return false;
    }

    public static void clearConsole() {
        try {
            new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();// kuha ko kay gpt diko alam mag clear
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
